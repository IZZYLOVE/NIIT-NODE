const blogRouter = require("./blogs.api");
module.exports = blogRouter;