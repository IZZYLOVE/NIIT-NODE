const authRouter = require('./authRouter')

module.exports = authRouter;