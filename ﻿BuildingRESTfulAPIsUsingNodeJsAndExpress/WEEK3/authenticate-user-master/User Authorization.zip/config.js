// const config ={
//     PORT: process.env.PORT ||3000,
//    AUTH_SECRET: process.env.AUTH_SECRET || "secret",
// }

// module.exports = config

const config = {
    PORT: process.env.PORT || 3000,
    AUTH_SECRET: process.env.AUTH_SECRET || 'e5f785ef6a8214e8a6d857325d07e0a9de28aeb7ec07f29ea50a0d2656d8b79d1f6931b2194c9032c9db90a0f3a5255c3d1b0cc8a200f88e2a5115a74107b45f9',
  };
  
  module.exports = config;
  