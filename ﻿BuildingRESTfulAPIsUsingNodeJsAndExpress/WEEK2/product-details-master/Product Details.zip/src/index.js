const productsRouter = require("./productsRouter");

module.exports = productsRouter;
